# Apply the classifier/model to the test data
y_pred = model.predict(X_test)
print(y_pred.shape)
