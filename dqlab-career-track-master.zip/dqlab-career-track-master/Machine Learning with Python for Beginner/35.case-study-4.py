#5. Cek missing value
print("\n[5] Cek missing value")
print(data.isnull().sum().sum())
