# Cetak tipe data di setiap kolom retail_raw
print(retail_raw.dtypes)