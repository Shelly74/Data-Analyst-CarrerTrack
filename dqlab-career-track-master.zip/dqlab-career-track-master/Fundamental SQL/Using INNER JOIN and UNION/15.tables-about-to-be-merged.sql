SELECT * FROM tabel_A;
SELECT * FROM tabel_B;