select * from tr_penjualan;
select * from ms_produk;