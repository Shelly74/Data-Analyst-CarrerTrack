select * from ms_item_kategori;
select * from ms_item_warna;