# Fitur .strip()
print(">>> Fitur .strip()")
kata_sambutan = ' halo, selamat siang!   '
kata_sambutan = kata_sambutan.strip()
print(kata_sambutan)
# Fitur .lstrip()
print(">>> Fitur .lstrip()")
kata_sambutan = ' halo, selamat siang!   '
kata_sambutan = kata_sambutan.lstrip()
print(kata_sambutan)
# Fitur .rstrip()
print(">>> Fitur .rstrip()")
kata_sambutan = ' halo, selamat siang!   '
kata_sambutan = kata_sambutan.rstrip()
print(kata_sambutan)