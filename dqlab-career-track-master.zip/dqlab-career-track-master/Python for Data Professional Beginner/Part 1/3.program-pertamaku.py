print("Halo Dunia")
print("Riset Bahasa Python")