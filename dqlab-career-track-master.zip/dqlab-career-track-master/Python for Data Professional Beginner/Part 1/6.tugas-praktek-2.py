harga_asli = 20000
potongan = 2000
harga_setelah_potongan = harga_asli-potongan
harga_final = harga_setelah_potongan*1.1
print(harga_final)