list_daerah = ['Malang', 'Palembang', 'Medan']
list_buah = ['Apel', 'Duku', 'Jeruk']
for nama_daerah in list_daerah :
    for nama_buah in list_buah :
        print(nama_buah+" "+nama_daerah)