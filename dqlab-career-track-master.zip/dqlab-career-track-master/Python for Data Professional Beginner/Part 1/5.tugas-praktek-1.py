bilangan1 = 20
bilangan2 = 10
print(bilangan1 - bilangan2)