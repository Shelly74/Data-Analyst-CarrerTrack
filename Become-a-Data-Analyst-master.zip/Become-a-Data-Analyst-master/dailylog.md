[How to become a data analyst？](README.md)

# Daily log
![Become a data analyst!](extras/Data-Analyst.png)
## Table of contents
- [2017](#2017)
  - [January](#January)
  - [February](#february)
  - [March](#march)
  - [April](#april)



### 2017

#### April

##### April 22
  - Read python for data analysis

##### April 22
  - Finished project2
  - Planned to read python for data analysis this weekend !

##### April 21
  - Finished ensemble Learning
  - Started Project2 and planned to finish it before next Monday

##### April 19
  - Learned Navie bayes and ensemble Learning

  I started to learn ML, but was tired of understand all formula and how to get these formula. It is necessary to learn in detail after finishing the supervised learning project.

#### March

##### March 6
 - I forgot to write daily log last several days. But I still kept coding.
 - Learning "Design of Computer Programs" - CS212, which is a little difficult. Currently, I just finished unit2.

#### February

##### Feb 23
 - Reading Python for Data Analysis chapter 4
 - Wrangling data from Douban

##### Feb 22
  - Finish Python for Data Analysis chapter 4
  - learn pyspider

##### Feb 21
 - Finish Python for Data Analysis chapter 2
 - learn API on codecademy

##### Feb 20
 - Read Python for Data Analysis chapter 2

##### Feb 19
   - Learning python on IMOCC

##### Feb 18
 - Pass the Project 7
 - Modify the resume

##### Feb 17
 - Finish the Project 7
 - Make the Starbucks location worldwide visualization

##### Feb 16
 - Pass the project 6
 - finish the Project 7 lessons

##### Feb 15
 - Submit new version of final project 6
 - Finish Design a experiments

##### Feb 14
 - Finish Policy and Ethics for Experiments

##### Feb 13
 - Finish the overview of A/B Testing

##### Feb 12
 - Finish the 2st version of P6 final project.

##### Feb 11
 - Finish all the lesson for P6!
 - Finish the 1st version of P6 final project, waiting for feedback.

##### Feb 10
 - Finsh 20/50 for P6 animation and intercation
 - Pass the project 5! Only 2 project left!

##### Feb 9
 - Finish the whole lesson 3 in p6

##### Feb 8
 - Finish p6-5 D3 Dimple.js
 - Study half of p6-6
 - Try to create [first dimple chart](http://bl.ocks.org/clarkyu2016/fdee38a185c8c1257cf337e96b89ab8d)

##### Feb 7
 - Finish p6-4 D3 Design Principle
 - Upload project 5 report to my github

##### Feb 6
 - Finish p6-2/3 D3 building block

##### Feb 5
 - Upload project 5 notes
 - Finish P6-1 visualization Fundamentals
 - Pass p4! Upload the project 4

##### Feb 4
 - Finish project 5
 - translate project 4 to Chinese version and put it on [Jianshu.com](http://www.jianshu.com/p/b690974e8146).

##### Feb 3
 - Finish the project 4 report, make some change and progress according to the review.
 - Work on project 5

##### Feb 2
 - Coedefights arcade - 16/162

##### Feb 1
 - 完成Udacity的validation小节
 - 完成Udacity的Evaluation metric小节



#### January
##### Jan 31
 - 完成Udacity的Feature Selection小节
 - 完成codefights里arcade一个关卡（目前进度：core-13/162)
 - 完成Udacity的PCA小节

##### Jan 30
 - 完成Udacity的Clustering小节
 - 完成Udacity的Feature Scalling小节
 - 完成Udacity的Text Learning小节

##### Jan 29
 - 完成Udacity的regression小节
 - 完成Udacity的Outliers小节

##### Jan 28
 - 改了一个下午的report
 - 完成Choose your own algorithm小节
 - 完成了对Enron dataset的初步探索

##### Jan 27
 - 完成udacity的SVM小节
 - 完成udacity的Decision Tree小节
 - 由于自己乱搞，多安装了一次numpy，重新配置了本地环境，最后用pip uninstall numpy才修复

##### Jan 26
 - Codefights一个关卡
 - Machine learning中SVM概念学习
