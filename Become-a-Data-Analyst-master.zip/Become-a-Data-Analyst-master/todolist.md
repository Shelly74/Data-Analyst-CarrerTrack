[How to become a data analyst？](README.md)

# To Do list

### Writing plan
  - [x] Translate [skills list](http://www.jianshu.com/p/cdc2bb769841) into Chinese and add some comments

### Online Course
  - [ ] Udacity machine-learning Nanodegree
  - [ ] [Calculus - khanacademy](https://www.khanacademy.org/math/calculus-home)
  - [ ] Udacity CS212  —— [Design of Computer Programs](https://www.udacity.com/course/design-of-computer-programs--cs212)
  - [x] [Programming Foundations with Python](https://www.udacity.com/course/programming-foundations-with-python--ud036)
  - [x] Udacity CS101 —— [Intro to Computer Science](https://www.udacity.com/course/intro-to-computer-science--cs101)
  - [x] Udacity Data Analyst Nanodegree —— [Data Analyst Nanodegree](https://www.udacity.com/course/data-analyst-nanodegree--nd002)


### Reading list
  - [ ] Python for Data Analysis(Progress: reading now!)
  - [ ] R for Beginners
  - [ ] Think python: How to think like a computer scientist second edition

### learning language
  - [ ] Python
    - [ ] Regular Expression
    - [ ] Web Crawling (Progress: learned simple Pysider)
    - [ ] Python [format](https://pyformat.info/)
    - [ ] Improve python skills by [CodeFights](https://codefights.com/)

### Build my own learning library
  - [ ] keep adding materials, notes, books there
  - [x] Translate current readme.me to English version

### Visualization
  - [ ] Use d3.js or dimple.js to draw a graph show my body with each sports hurt and make it interactive.

### Machine learning
  - [ ] Use machine learning algorithm to find water army and fake rating on Douban Movie.
